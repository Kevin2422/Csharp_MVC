using Microsoft.AspNetCore.Mvc;
namespace dojoSurvey
{
    public class SurveyController : Controller
    {
        [HttpGet("")]
        public ViewResult Survey()
        {
            return View();
        }
        [HttpPost("result")]
        public ViewResult Results(UserData user)
        {
           
            return View(user);
        }
    }
}