public class UserData
{
    public string name {get;set;}
    public string location {get;set;}
    public string language {get;set;}
    public string Comments {get;set;}
}