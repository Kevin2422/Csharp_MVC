using Microsoft.AspNetCore.Mvc;
namespace portfoliio
{
    public class HomeController : Controller
    {
        [Route("")]
        [HttpGet]
        public string HelloFromController()
        {
            return "This is my Index";
        }

        
        [HttpGet ("projects")]
        public string Hello()
        {
            return "These are my projects";
        }

        [HttpGet("contact")]
        public string HelloUser()
        {
            return "This is my contact!";
        }


    }

}